#This is the R code that was used to generate the data used in the practical

#==============parameters====================

parameter<-c(3,0.5,3)
m.incub<-parameter[1]		#mean duration of the incubation period
beta<-parameter[2]		#transmission rate
m.inf<-parameter[3]		#mean generation time (time from infection of donor to infection of secondary case)

proportion.children<-0.4


#----
n.cluster<-200	#number of clusters: each cluster is made of 1 donor and 1 recipient

dt<-0.001
T.max<-50
timepoints<-seq(0,T.max,by=dt)
probatimePoint<-(exp(-beta*pexp(timepoints,1/m.inf))-exp(-beta*pexp(timepoints+dt,1/m.inf)))
plot(probatimePoint,type="l")
sum(probatimePoint)
1-exp(-beta)
probatimePoint<-probatimePoint/sum(probatimePoint)

drawTimeInfection<-function()
{return(timepoints[rmultinom(1,1,probatimePoint)==1]+runif(1)*dt)}


nameList<-c("time.infection.donor","time.onset.donor","recipient.infected","time.infection.recipient","time.onset.recipient","child.donor","child.recipient")
n.column<-length(nameList)

data<-data.frame(matrix(0,nrow=n.cluster,ncol=n.column))
names(data)<-nameList

data$time.infection.recipient<-rep(1000,n.cluster)
data$time.onset.recipient<-rep(1000,n.cluster)

for(cluster in 1:n.cluster)
    {data$time.onset.donor[cluster]<-rexp(1,1/m.incub)
    if(runif(1)<proportion.children) child.donor<-1
    if(runif(1)<proportion.children) child.recipient<-1
    if(runif(1)<1-exp(-beta))
	{data$recipient.infected[cluster]<-1
	time.infected.recipient<-drawTimeInfection()
	data$time.onset.recipient[cluster]<-time.infected.recipient+rexp(1,1/m.incub)
	#data$time.infection.recipient[cluster]<-time.infected.recipient
  	}
    }

data[1:10,]
mean(data$recipient.infected)
mean(data$time.infection.recipient[data$recipient.infected==1])
mean(data$time.onset.donor)
mean(data$time.onset.recipient[data$recipient.infected==1])
